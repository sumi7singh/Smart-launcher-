package com.smartlauncher

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat

@Composable
fun SettingsScreen(
    page: Int,
    widgets: WidgetStore,
    onAddWidget: (AppWidgetProviderInfo, Int) -> Unit,
    onClose: () -> Unit
) {
    BackHandler(onBack = onClose)
    var picking by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) { detectTapGestures { } }) {
        if (picking) {
            WidgetPicker(
                onPick = { picking = false; onAddWidget(it, page); onClose() },
                onBack = { picking = false }
            )
        } else {
            SettingsMain(page, widgets, onPickWidget = { picking = true }, onClose = onClose)
        }
    }
}

@Composable
private fun SettingsMain(page: Int, widgets: WidgetStore, onPickWidget: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val notifGranted = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    val a11yOn = LauncherAccessibilityService.instance != null
    val pageName = listOf("left", "home", "right").getOrElse(page) { "home" }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(24.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Settings", color = Color.White, fontSize = 28.sp, modifier = Modifier.weight(1f))
            Text("Done", color = Prefs.accent, fontSize = 16.sp, modifier = Modifier.tap(onClick = onClose).padding(8.dp))
        }

        Section("Accent colour")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Prefs.accents.forEach { (_, c) ->
                val selected = Prefs.accent == c
                Box(
                    Modifier.size(36.dp).clip(CircleShape).background(c)
                        .border(if (selected) 3.dp else 1.dp, if (selected) Color.White else Color.Gray, CircleShape)
                        .tap { Prefs.setAccent(c) },
                    contentAlignment = Alignment.Center
                ) {
                    if (selected) Box(Modifier.size(10.dp).clip(CircleShape).background(Color.Black))
                }
            }
        }

        Section("Notification bar")
        ToggleRow("Show summary bar", Prefs.summariesOn) { Prefs.setSummaries(it) }
        Text(
            if (notifGranted) "Notification access: ON" else "Notification access: OFF",
            color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(vertical = 4.dp)
        )
        Btn("Open notification access settings") {
            ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        Spacer(Modifier.height(12.dp))
        ToggleRow("AI summaries & smart replies (Claude)", Prefs.aiOn) { Prefs.setAi(it) }
        if (Prefs.aiOn) {
            Text(
                "Sends the app name, title and text of each notification to Anthropic using your own API key. " +
                    "OTP and banking-looking messages stay on the phone. The key is stored privately on this device.",
                color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp)
            )
            BasicTextField(
                value = Prefs.apiKey,
                onValueChange = { Prefs.setApiKey(it.trim()) },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                cursorBrush = SolidColor(Prefs.accent),
                modifier = Modifier.fillMaxWidth()
                    .border(1.dp, Color(0xFF444444), RoundedCornerShape(8.dp)).padding(12.dp),
                decorationBox = { inner ->
                    Box {
                        if (Prefs.apiKey.isEmpty()) Text("Anthropic API key (sk-ant-...)", color = Color.Gray, fontSize = 15.sp)
                        inner()
                    }
                }
            )
        }

        Section("Gestures")
        Text(
            if (a11yOn) "Swipe-down gestures: ON" else "Swipe-down gestures: needs Accessibility",
            color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(vertical = 4.dp)
        )
        Btn("Open accessibility settings") {
            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }

        Section("Widgets ($pageName screen)")
        Btn("Add widget to this screen") { onPickWidget() }
        widgets.idsFor(page).forEach { id ->
            val label = widgets.mgr.getAppWidgetInfo(id)?.loadLabel(ctx.packageManager) ?: "Widget"
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(label, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Text("Remove", color = Color.Gray, fontSize = 14.sp, modifier = Modifier.tap { widgets.remove(id) }.padding(8.dp))
            }
        }

        Section("Home app")
        Btn("Choose default home app") {
            ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun WidgetPicker(onPick: (AppWidgetProviderInfo) -> Unit, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val ctx = LocalContext.current
    val providers = remember {
        AppWidgetManager.getInstance(ctx).installedProviders
            .sortedBy { it.loadLabel(ctx.packageManager).lowercase() }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Choose widget", color = Color.White, fontSize = 24.sp, modifier = Modifier.weight(1f))
            Text("Back", color = Prefs.accent, fontSize = 16.sp, modifier = Modifier.tap(onClick = onBack).padding(8.dp))
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn {
            items(providers) { p ->
                Column(Modifier.fillMaxWidth().tap { onPick(p) }.padding(vertical = 10.dp)) {
                    Text(p.loadLabel(ctx.packageManager), color = Color.White, fontSize = 18.sp)
                    Text(p.provider.packageName, color = Color.Gray, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun Section(title: String) {
    Text(
        title.uppercase(), color = Prefs.accent, fontSize = 12.sp, letterSpacing = 1.sp,
        modifier = Modifier.padding(top = 28.dp, bottom = 8.dp)
    )
}

@Composable
private fun Btn(text: String, onClick: () -> Unit) {
    Text(
        text, color = Color.White, fontSize = 15.sp,
        modifier = Modifier.padding(vertical = 4.dp)
            .border(1.dp, Prefs.accent.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
            .tap(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    )
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black, checkedTrackColor = Prefs.accent,
                uncheckedThumbColor = Color.Gray, uncheckedTrackColor = Color(0xFF222222),
                uncheckedBorderColor = Color.Gray
            )
        )
    }
}
