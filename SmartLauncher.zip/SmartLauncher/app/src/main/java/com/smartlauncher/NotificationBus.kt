package com.smartlauncher

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateListOf

data class NotifItem(
    val key: String,
    val app: String,
    val summary: String,
    val replies: List<String>,
    val canReply: Boolean
)

/** Bridge between the notification listener service and the launcher UI. */
object NotificationBus {
    val queue = mutableStateListOf<NotifItem>()
    private val replyActions = HashMap<String, Notification.Action>()
    private val openIntents = HashMap<String, PendingIntent>()
    private val main = Handler(Looper.getMainLooper())

    fun post(item: NotifItem, reply: Notification.Action?, open: PendingIntent?) {
        main.post {
            if (reply != null) replyActions[item.key] = reply
            if (open != null) openIntents[item.key] = open
            val i = queue.indexOfFirst { it.key == item.key }
            if (i >= 0) { queue[i] = item } else { queue.add(item) }
        }
    }

    fun update(item: NotifItem) {
        main.post {
            val i = queue.indexOfFirst { it.key == item.key }
            if (i >= 0) queue[i] = item
        }
    }

    fun dismiss(key: String) {
        main.post {
            queue.removeAll { it.key == key }
            replyActions.remove(key)
            openIntents.remove(key)
        }
    }

    /** Sends the reply through the notification's own inline-reply action (WhatsApp, SMS, ...). */
    fun sendReply(ctx: Context, key: String, text: String): Boolean {
        val action = replyActions[key] ?: return false
        val inputs = action.remoteInputs ?: return false
        val intent = Intent()
        val bundle = Bundle()
        for (ri in inputs) bundle.putCharSequence(ri.resultKey, text)
        RemoteInput.addResultsToIntent(inputs, intent, bundle)
        return try {
            action.actionIntent.send(ctx, 0, intent)
            true
        } catch (e: PendingIntent.CanceledException) {
            false
        }
    }

    fun open(key: String) {
        try { openIntents[key]?.send() } catch (e: PendingIntent.CanceledException) { }
    }
}
