package com.smartlauncher

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toAndroidRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.ViewCompat

/** Hidden shortcut panel: a thin handle on the right edge; tap or drag it to slide the panel out. */
@Composable
fun SideSlider(
    open: Boolean,
    apps: List<AppInfo>,
    pins: Pins,
    onOpen: () -> Unit,
    onClose: () -> Unit,
    onLaunch: (String) -> Unit
) {
    val view = LocalView.current
    BackHandler(enabled = open, onBack = onClose)
    val labels = remember(apps) { apps.associate { it.pkg to it.label } }
    val pinned = pins.pages[3].orEmpty().filter { it in labels }

    Box(Modifier.fillMaxSize()) {
        // Handle (also excluded from the system back gesture so the edge swipe works)
        Box(
            Modifier.align(Alignment.CenterEnd).width(26.dp).height(140.dp)
                .onGloballyPositioned {
                    ViewCompat.setSystemGestureExclusionRects(view, listOf(it.boundsInWindow().toAndroidRect()))
                }
                .pointerInput(Unit) { detectHorizontalDragGestures { _, dx -> if (dx < -6f) onOpen() } }
                .tap { onOpen() },
            contentAlignment = Alignment.CenterEnd
        ) {
            Box(
                Modifier.padding(end = 3.dp).width(4.dp).height(72.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Prefs.accent.copy(alpha = 0.7f))
            )
        }

        AnimatedVisibility(visible = open, enter = fadeIn(), exit = fadeOut()) {
            Box(Modifier.fillMaxSize().background(Color(0x99000000)).tap { onClose() })
        }

        AnimatedVisibility(
            visible = open,
            modifier = Modifier.align(Alignment.CenterEnd),
            enter = slideInHorizontally { it },
            exit = slideOutHorizontally { it }
        ) {
            Row(Modifier.fillMaxHeight().width(250.dp)) {
                Box(Modifier.fillMaxHeight().width(1.dp).background(Prefs.accent.copy(alpha = 0.6f)))
                Column(
                    Modifier.fillMaxHeight().weight(1f).background(Color.Black)
                        .statusBarsPadding().navigationBarsPadding().padding(20.dp)
                ) {
                    Text("SHORTCUTS", color = Prefs.accent, fontSize = 12.sp, letterSpacing = 1.sp)
                    Spacer(Modifier.height(16.dp))
                    if (pinned.isEmpty()) {
                        Text(
                            "Long-press an app in the drawer and choose \"Pin to side slider\".",
                            color = Color.Gray, fontSize = 14.sp
                        )
                    }
                    pinned.forEach { pkg ->
                        Text(
                            labels[pkg] ?: pkg, color = Color.White, fontSize = 20.sp,
                            modifier = Modifier.fillMaxWidth()
                                .tap { onLaunch(pkg) }
                                .padding(vertical = 12.dp)
                        )
                    }
                }
            }
        }
    }
}
