package com.smartlauncher

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class LauncherNotificationListener : NotificationListenerService() {
    private val seen = HashMap<String, String>()

    private val skipCategories = setOf(
        Notification.CATEGORY_PROGRESS, Notification.CATEGORY_TRANSPORT,
        Notification.CATEGORY_SERVICE, Notification.CATEGORY_SYSTEM, Notification.CATEGORY_STATUS
    )

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Prefs.summariesOn) return
        if (sbn.packageName == packageName || sbn.isOngoing) return
        val n = sbn.notification
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (n.category in skipCategories) return

        val extras = n.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        val key = sbn.key
        val sig = "$title|$text"
        if (seen[key] == sig) return
        seen[key] = sig

        val pm = packageManager
        val app = try {
            pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }

        val reply = n.actions?.firstOrNull { a -> !a.remoteInputs.isNullOrEmpty() }
        val item = NotifItem(
            key = key,
            app = app,
            summary = Summarizer.local(title, text),
            replies = Summarizer.localReplies(text),
            canReply = reply != null
        )
        NotificationBus.post(item, reply, n.contentIntent)

        // Optional cloud summary. OTP / banking-looking messages never leave the device.
        val apiKey = Prefs.apiKey
        if (Prefs.aiOn && apiKey.isNotBlank() && !Summarizer.isSensitive(app, title, text)) {
            Thread {
                val res = Claude.summarize(apiKey, app, title, text, reply != null)
                if (res != null) {
                    NotificationBus.update(
                        item.copy(
                            summary = res.first,
                            replies = if (res.second.isEmpty()) item.replies else res.second
                        )
                    )
                }
            }.start()
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        seen.remove(sbn.key)
        NotificationBus.dismiss(sbn.key)
    }
}
