package com.smartlauncher

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

/** App-wide settings. Call Prefs.init(context) before use (activity and services both do). */
object Prefs {
    val accents = listOf(
        "White" to Color(0xFFFFFFFF), "Cyan" to Color(0xFF00E5FF), "Green" to Color(0xFF69F0AE),
        "Amber" to Color(0xFFFFD740), "Red" to Color(0xFFFF5252), "Magenta" to Color(0xFFE040FB)
    )

    private var prefs: SharedPreferences? = null

    var accent by mutableStateOf(Color.White)
    var summariesOn by mutableStateOf(true)
    var aiOn by mutableStateOf(false)
    var apiKey by mutableStateOf("")

    @Synchronized
    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
        prefs = p
        accent = Color(p.getInt("accent", Color.White.toArgb()))
        summariesOn = p.getBoolean("summaries", true)
        aiOn = p.getBoolean("ai", false)
        apiKey = p.getString("apiKey", "") ?: ""
    }

    fun setAccent(c: Color) { accent = c; prefs?.edit()?.putInt("accent", c.toArgb())?.apply() }
    fun setSummaries(v: Boolean) { summariesOn = v; prefs?.edit()?.putBoolean("summaries", v)?.apply() }
    fun setAi(v: Boolean) { aiOn = v; prefs?.edit()?.putBoolean("ai", v)?.apply() }
    fun setApiKey(v: String) { apiKey = v; prefs?.edit()?.putString("apiKey", v)?.apply() }
}
