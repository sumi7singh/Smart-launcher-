package com.smartlauncher

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppDrawer(
    apps: List<AppInfo>,
    onLaunch: (String) -> Unit,
    onPin: (AppInfo, Int) -> Unit,
    onClose: () -> Unit
) {
    BackHandler(onBack = onClose)
    var query by remember { mutableStateOf("") }
    var menuApp by remember { mutableStateOf<AppInfo?>(null) }
    val filtered = remember(apps, query) { apps.filter { it.label.contains(query, ignoreCase = true) } }

    Column(
        Modifier.fillMaxSize().background(Color.Black)
            .statusBarsPadding().navigationBarsPadding().imePadding()
            .padding(horizontal = 24.dp)
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        BasicTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 20.sp),
            cursorBrush = SolidColor(Prefs.accent),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
            keyboardActions = KeyboardActions(onGo = { filtered.firstOrNull()?.let { onLaunch(it.pkg) } }),
            modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
            decorationBox = { inner ->
                Box {
                    if (query.isEmpty()) Text("Search", color = Color.Gray, fontSize = 20.sp)
                    inner()
                }
            }
        )
        HorizontalDivider(color = Color(0xFF333333))
        LazyColumn(Modifier.fillMaxSize()) {
            items(filtered, key = { it.pkg }) { app ->
                Text(
                    app.label,
                    color = Color.White,
                    fontSize = 20.sp,
                    modifier = Modifier.fillMaxWidth()
                        .combinedClickable(onClick = { onLaunch(app.pkg) }, onLongClick = { menuApp = app })
                        .padding(vertical = 14.dp)
                )
            }
        }
    }

    menuApp?.let { app ->
        AlertDialog(
            onDismissRequest = { menuApp = null },
            containerColor = Color(0xFF111111),
            title = { Text(app.label, color = Color.White) },
            text = {
                Column {
                    listOf("Pin to home" to 1, "Pin to left screen" to 0, "Pin to right screen" to 2, "Pin to side slider" to 3)
                        .forEach { (label, page) ->
                            TextButton(onClick = { onPin(app, page); menuApp = null }) {
                                Text(label, color = Color.White)
                            }
                        }
                }
            },
            confirmButton = {}
        )
    }
}
