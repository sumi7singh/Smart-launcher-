package com.smartlauncher

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Accent = Color(0xFFFFFFFF) // TODO: user-selectable contrast colour (step 7)

@Composable
fun LauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, background = Color.Black, surface = Color.Black,
            onBackground = Color.White, onSurface = Color.White
        ),
        content = content
    )
}
