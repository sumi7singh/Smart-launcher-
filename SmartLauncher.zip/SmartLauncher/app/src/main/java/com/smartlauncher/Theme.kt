package com.smartlauncher

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun LauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Prefs.accent, background = Color.Black, surface = Color.Black,
            onBackground = Color.White, onSurface = Color.White
        ),
        content = content
    )
}
