package com.smartlauncher

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/** Lets the launcher open the notification shade / quick settings (Android has no direct API). */
class LauncherAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    companion object {
        @Volatile var instance: LauncherAccessibilityService? = null

        fun run(ctx: Context, action: Int) {
            val s = instance
            if (s == null) {
                Toast.makeText(ctx, "Enable Smart Launcher in Accessibility settings", Toast.LENGTH_LONG).show()
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } else s.performGlobalAction(action)
        }
        fun openNotifications(ctx: Context) = run(ctx, GLOBAL_ACTION_NOTIFICATIONS)
        fun openQuickSettings(ctx: Context) = run(ctx, GLOBAL_ACTION_QUICK_SETTINGS)
    }
}
