package com.smartlauncher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.compose.runtime.mutableStateMapOf

data class AppInfo(val label: String, val pkg: String)

fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        .filter { it.pkg != ctx.packageName }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

fun launchApp(ctx: Context, pkg: String) {
    ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it) }
}

/** Pinned apps per page: 0 = left screen, 1 = home, 2 = right screen. */
class Pins(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("pins", Context.MODE_PRIVATE)
    val pages = mutableStateMapOf<Int, List<String>>()

    init { for (p in 0..2) pages[p] = load(p) }

    private fun load(p: Int) = prefs.getString("p$p", "")!!.split(",").filter { it.isNotBlank() }
    private fun save(p: Int, l: List<String>) {
        pages[p] = l
        prefs.edit().putString("p$p", l.joinToString(",")).apply()
    }
    fun add(p: Int, pkg: String) { val l = pages[p].orEmpty(); if (pkg !in l) save(p, l + pkg) }
    fun remove(p: Int, pkg: String) = save(p, pages[p].orEmpty() - pkg)
}
