package com.smartlauncher

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Small bar that slides in from the right with a notification summary; tap to reply. */
@Composable
fun NotificationBar(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val item = NotificationBus.queue.firstOrNull()
    var last by remember { mutableStateOf<NotifItem?>(null) }
    LaunchedEffect(item) { if (item != null) last = item }
    val shown = item ?: last
    var expanded by remember(item?.key) { mutableStateOf(false) }
    var draft by remember(item?.key) { mutableStateOf("") }

    // Auto-hide to the right after 8s unless the user opened it.
    LaunchedEffect(item?.key, expanded) {
        val k = item?.key
        if (k != null && !expanded) {
            delay(8000)
            NotificationBus.dismiss(k)
        }
    }

    val shape = RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp)

    AnimatedVisibility(
        visible = item != null,
        modifier = modifier,
        enter = slideInHorizontally { it } + fadeIn(),
        exit = slideOutHorizontally { it } + fadeOut()
    ) {
        val n = shown
        if (n != null) {
            fun send(t: String) {
                if (t.isBlank()) return
                if (NotificationBus.sendReply(ctx, n.key, t.trim())) {
                    NotificationBus.dismiss(n.key)
                } else {
                    Toast.makeText(ctx, "Reply failed", Toast.LENGTH_SHORT).show()
                }
            }

            Column(
                Modifier.padding(top = 16.dp).width(290.dp)
                    .background(Color(0xFF0D0D0D), shape)
                    .border(1.dp, Prefs.accent.copy(alpha = 0.7f), shape)
                    .tap(enabled = !expanded) { expanded = true }
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        n.app.uppercase(), color = Prefs.accent, fontSize = 11.sp,
                        letterSpacing = 1.sp, modifier = Modifier.weight(1f)
                    )
                    if (expanded) {
                        Text(
                            "✕", color = Color.Gray, fontSize = 16.sp,
                            modifier = Modifier.tap { NotificationBus.dismiss(n.key) }.padding(4.dp)
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    n.summary, color = Color.White, fontSize = 15.sp,
                    maxLines = if (expanded) 6 else 3, overflow = TextOverflow.Ellipsis
                )
                if (!expanded) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (n.canReply) "Tap to reply" else "Tap for options",
                        color = Color.Gray, fontSize = 11.sp
                    )
                } else {
                    Spacer(Modifier.height(12.dp))
                    if (n.canReply) {
                        n.replies.take(3).forEach { r ->
                            Text(
                                r, color = Color.White, fontSize = 14.sp,
                                modifier = Modifier.padding(bottom = 6.dp)
                                    .border(1.dp, Prefs.accent.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                                    .tap { send(r) }
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                        Row(
                            Modifier.fillMaxWidth()
                                .border(1.dp, Color(0xFF444444), RoundedCornerShape(20.dp))
                                .padding(start = 14.dp, end = 10.dp, top = 8.dp, bottom = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            BasicTextField(
                                value = draft,
                                onValueChange = { draft = it },
                                textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                                cursorBrush = SolidColor(Prefs.accent),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                keyboardActions = KeyboardActions(onSend = { send(draft) }),
                                modifier = Modifier.weight(1f),
                                decorationBox = { inner ->
                                    Box {
                                        if (draft.isEmpty()) Text("Type a reply", color = Color.Gray, fontSize = 14.sp)
                                        inner()
                                    }
                                }
                            )
                            Text(
                                "Send", color = Prefs.accent, fontSize = 14.sp,
                                modifier = Modifier.tap { send(draft) }.padding(start = 8.dp)
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                    }
                    Row {
                        Text(
                            "Open", color = Color.Gray, fontSize = 13.sp,
                            modifier = Modifier.tap {
                                NotificationBus.open(n.key)
                                NotificationBus.dismiss(n.key)
                            }.padding(vertical = 4.dp)
                        )
                        Spacer(Modifier.weight(1f))
                        Text(
                            "Dismiss", color = Color.Gray, fontSize = 13.sp,
                            modifier = Modifier.tap { NotificationBus.dismiss(n.key) }.padding(vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}
