package com.smartlauncher

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.content.Context
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

/** Hosts Android home-screen widgets. Each widget is stored as (widgetId, page). */
class WidgetStore(ctx: Context) {
    val host = AppWidgetHost(ctx.applicationContext, 1024)
    val mgr: AppWidgetManager = AppWidgetManager.getInstance(ctx.applicationContext)
    private val prefs = ctx.getSharedPreferences("widgets", Context.MODE_PRIVATE)
    val items = mutableStateListOf<Pair<Int, Int>>()

    init {
        (prefs.getString("w", "") ?: "").split(",").filter { it.contains(":") }.forEach {
            val parts = it.split(":")
            val id = parts[0].toIntOrNull()
            val page = parts[1].toIntOrNull()
            if (id != null && page != null) items.add(id to page)
        }
    }

    private fun save() {
        prefs.edit().putString("w", items.joinToString(",") { "${it.first}:${it.second}" }).apply()
    }

    fun idsFor(page: Int): List<Int> = items.filter { it.second == page }.map { it.first }

    fun add(id: Int, page: Int) { items.add(id to page); save() }

    fun remove(id: Int) {
        host.deleteAppWidgetId(id)
        items.removeAll { it.first == id }
        save()
    }
}

@Composable
fun WidgetView(store: WidgetStore, id: Int) {
    val info = remember(id) { store.mgr.getAppWidgetInfo(id) } ?: return
    val h = with(LocalDensity.current) { info.minHeight.toDp() }
    AndroidView(
        factory = { ctx -> store.host.createView(ctx, id, info) },
        modifier = Modifier.fillMaxWidth().height(maxOf(h, 56.dp))
    )
}
