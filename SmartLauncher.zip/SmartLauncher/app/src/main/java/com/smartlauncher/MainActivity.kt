package com.smartlauncher

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {
    private var apps by mutableStateOf(listOf<AppInfo>())
    private var homeTick by mutableIntStateOf(0)
    private lateinit var pins: Pins
    private lateinit var widgets: WidgetStore
    private var pendingId = -1
    private var pendingPage = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        enableEdgeToEdge()
        pins = Pins(this)
        widgets = WidgetStore(this)
        setContent {
            LauncherTheme {
                HomeScreen(
                    apps = apps,
                    pins = pins,
                    widgets = widgets,
                    homeTick = homeTick,
                    onLaunch = { launchApp(this, it) },
                    onNotifications = { LauncherAccessibilityService.openNotifications(this) },
                    onQuickSettings = { LauncherAccessibilityService.openQuickSettings(this) },
                    onAddWidget = { info, page -> addWidget(info, page) }
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        widgets.host.startListening()
    }

    override fun onStop() {
        super.onStop()
        widgets.host.stopListening()
    }

    override fun onResume() {
        super.onResume()
        apps = loadApps(this) // refresh after installs/uninstalls
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN) homeTick++
    }

    // ---- Widget add flow: bind (system permission dialog) -> configure (if needed) -> store ----

    @Suppress("DEPRECATION")
    private fun addWidget(info: AppWidgetProviderInfo, page: Int) {
        val id = widgets.host.allocateAppWidgetId()
        pendingId = id
        pendingPage = page
        if (widgets.mgr.bindAppWidgetIdIfAllowed(id, info.provider)) {
            configureOrFinish(id)
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            startActivityForResult(i, REQ_BIND)
        }
    }

    private fun configureOrFinish(id: Int) {
        val cfg = widgets.mgr.getAppWidgetInfo(id)?.configure
        if (cfg != null) {
            widgets.host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG, null)
        } else {
            finishAdd(id)
        }
    }

    private fun finishAdd(id: Int) {
        widgets.add(id, pendingPage)
        pendingId = -1
    }

    @Deprecated("Deprecated in Java")
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_BIND && requestCode != REQ_CONFIG) return
        val id = pendingId
        if (id < 0) return
        if (resultCode == RESULT_OK) {
            if (requestCode == REQ_BIND) configureOrFinish(id) else finishAdd(id)
        } else {
            widgets.host.deleteAppWidgetId(id)
            pendingId = -1
        }
    }

    companion object {
        private const val REQ_BIND = 101
        private const val REQ_CONFIG = 102
    }
}
