package com.smartlauncher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {
    private var apps by mutableStateOf(listOf<AppInfo>())
    private var homeTick by mutableIntStateOf(0)
    private lateinit var pins: Pins

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        pins = Pins(this)
        setContent {
            LauncherTheme {
                HomeScreen(
                    apps = apps,
                    pins = pins,
                    homeTick = homeTick,
                    onLaunch = { launchApp(this, it) },
                    onNotifications = { LauncherAccessibilityService.openNotifications(this) },
                    onQuickSettings = { LauncherAccessibilityService.openQuickSettings(this) }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        apps = loadApps(this) // refresh after installs/uninstalls
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN) homeTick++
    }
}
