package com.smartlauncher

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Composable
fun HomeScreen(
    apps: List<AppInfo>,
    pins: Pins,
    homeTick: Int,
    onLaunch: (String) -> Unit,
    onNotifications: () -> Unit,
    onQuickSettings: () -> Unit
) {
    val pager = rememberPagerState(initialPage = 1) { 3 }
    var drawerOpen by remember { mutableStateOf(false) }

    // Home button pressed while we're already open: reset to the main screen.
    LaunchedEffect(homeTick) {
        if (homeTick > 0) { drawerOpen = false; pager.animateScrollToPage(1) }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Box(
            Modifier.fillMaxSize().pointerInput(Unit) {
                var startX = 0f
                var total = 0f
                val threshold = 56.dp.toPx()
                detectVerticalDragGestures(
                    onDragStart = { startX = it.x; total = 0f },
                    onVerticalDrag = { _, dy -> total += dy },
                    onDragEnd = {
                        when {
                            total < -threshold -> drawerOpen = true
                            total > threshold ->
                                if (startX < size.width / 2f) onNotifications() else onQuickSettings()
                        }
                    }
                )
            }
        ) {
            HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
                PinnedPage(page, apps, pins, onLaunch)
            }
        }

        AnimatedVisibility(
            visible = drawerOpen,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            AppDrawer(
                apps = apps,
                onLaunch = { drawerOpen = false; onLaunch(it) },
                onPin = { app, page -> pins.add(page, app.pkg); drawerOpen = false },
                onClose = { drawerOpen = false }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PinnedPage(page: Int, apps: List<AppInfo>, pins: Pins, onLaunch: (String) -> Unit) {
    val labels = remember(apps) { apps.associate { it.pkg to it.label } }
    val pinned = pins.pages[page].orEmpty().filter { it in labels }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(32.dp),
        verticalArrangement = Arrangement.Center
    ) {
        if (page == 1) Clock()
        if (pinned.isEmpty() && page != 1) {
            Text("Long-press an app in the drawer to pin it here", color = Color.Gray, fontSize = 16.sp)
        }
        Spacer(Modifier.height(24.dp))
        pinned.forEach { pkg ->
            Text(
                labels[pkg] ?: pkg,
                color = Color.White,
                fontSize = 24.sp,
                modifier = Modifier.combinedClickable(
                    onClick = { onLaunch(pkg) },
                    onLongClick = { pins.remove(page, pkg) } // long-press to unpin
                ).padding(vertical = 10.dp)
            )
        }
    }
}

@Composable
private fun Clock() {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(10_000) } }
    Text(now.format(DateTimeFormatter.ofPattern("HH:mm")), color = Color.White, fontSize = 72.sp, fontWeight = FontWeight.Thin)
    Text(now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")), color = Color.Gray, fontSize = 18.sp)
}
