package com.smartlauncher

import android.appwidget.AppWidgetProviderInfo
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.abs

@Composable
fun HomeScreen(
    apps: List<AppInfo>,
    pins: Pins,
    widgets: WidgetStore,
    homeTick: Int,
    onLaunch: (String) -> Unit,
    onNotifications: () -> Unit,
    onQuickSettings: () -> Unit,
    onAddWidget: (AppWidgetProviderInfo, Int) -> Unit
) {
    val pager = rememberPagerState(initialPage = 1) { 3 }
    var drawerOpen by remember { mutableStateOf(false) }
    var sliderOpen by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }

    // Home button while already open: close everything and go back to the main screen.
    LaunchedEffect(homeTick) {
        if (homeTick > 0) {
            drawerOpen = false; sliderOpen = false; settingsOpen = false
            pager.animateScrollToPage(1)
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // Gesture layer: observes vertical swipes without stealing them from children.
        Box(
            Modifier.fillMaxSize().pointerInput(Unit) {
                val threshold = 56.dp.toPx()
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    val startX = down.position.x
                    var dx = 0f
                    var dy = 0f
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Initial)
                        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                        dx += ch.positionChange().x
                        dy += ch.positionChange().y
                        if (!ch.pressed) break
                    }
                    if (abs(dy) > threshold && abs(dy) > abs(dx) * 1.5f) {
                        when {
                            dy < 0 -> drawerOpen = true
                            startX < size.width / 2f -> onNotifications()
                            else -> onQuickSettings()
                        }
                    }
                }
            }
        ) {
            HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
                PinnedPage(page, apps, pins, widgets, onLaunch, onLongPress = { settingsOpen = true })
            }
        }

        NotificationBar(Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 56.dp))

        SideSlider(
            open = sliderOpen,
            apps = apps,
            pins = pins,
            onOpen = { sliderOpen = true },
            onClose = { sliderOpen = false },
            onLaunch = { sliderOpen = false; onLaunch(it) }
        )

        AnimatedVisibility(
            visible = drawerOpen,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            AppDrawer(
                apps = apps,
                onLaunch = { drawerOpen = false; onLaunch(it) },
                onPin = { app, page -> pins.add(page, app.pkg); drawerOpen = false },
                onClose = { drawerOpen = false }
            )
        }

        AnimatedVisibility(visible = settingsOpen, enter = fadeIn(), exit = fadeOut()) {
            SettingsScreen(
                page = pager.currentPage,
                widgets = widgets,
                onAddWidget = onAddWidget,
                onClose = { settingsOpen = false }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PinnedPage(
    page: Int,
    apps: List<AppInfo>,
    pins: Pins,
    widgets: WidgetStore,
    onLaunch: (String) -> Unit,
    onLongPress: () -> Unit
) {
    val labels = remember(apps) { apps.associate { it.pkg to it.label } }
    val pinned = pins.pages[page].orEmpty().filter { it in labels }
    val widgetIds = widgets.idsFor(page)

    Column(
        Modifier.fillMaxSize()
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onLongClick = onLongPress,
                onClick = {}
            )
            .statusBarsPadding().navigationBarsPadding()
            .padding(start = 28.dp, end = 28.dp, top = 56.dp, bottom = 24.dp)
    ) {
        if (page == 1) Clock()
        widgetIds.forEach { id ->
            WidgetView(widgets, id)
            Spacer(Modifier.height(12.dp))
        }
        Spacer(Modifier.height(12.dp))
        if (pinned.isEmpty() && widgetIds.isEmpty() && page != 1) {
            Text(
                "Pin apps from the drawer (long-press an app). Long-press empty space for settings and widgets.",
                color = Color.Gray, fontSize = 15.sp
            )
        }
        pinned.forEach { pkg ->
            Text(
                labels[pkg] ?: pkg,
                color = Color.White,
                fontSize = 24.sp,
                modifier = Modifier.combinedClickable(
                    onClick = { onLaunch(pkg) },
                    onLongClick = { pins.remove(page, pkg) } // long-press to unpin
                ).padding(vertical = 10.dp)
            )
        }
    }
}

@Composable
private fun Clock() {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(10_000) } }
    Text(
        now.format(DateTimeFormatter.ofPattern("HH:mm")),
        color = Prefs.accent, fontSize = 72.sp, fontWeight = FontWeight.Thin
    )
    Text(now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")), color = Color.Gray, fontSize = 18.sp)
    Spacer(Modifier.height(16.dp))
}
